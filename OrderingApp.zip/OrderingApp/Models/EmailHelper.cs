﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text.RegularExpressions;
using System.Web;

namespace OrderingApp.Models
{  
    public interface ISmtpClient
    {
        void Send(MailMessage message);
    }

    public class RealSmtpClient: ISmtpClient
    {
        public void Send(MailMessage message)
        {
            SmtpClient client = new SmtpClient();
            client.Send(message);
        }
    }

    public class FakeSmtpClient: ISmtpClient
    {
        public bool MailSent { get; set; }
        public FakeSmtpClient()
        {
            MailSent = false;
        }
        public void Send(MailMessage message)
        {
            MailSent = true;
        }
    }

    public class EmailHelper
    {
        private ISmtpClient smtpClient;

        public EmailHelper(ISmtpClient smtpClient)
        {
            this.smtpClient = smtpClient;
        }

        public void SendOrderEmail(string toAddress)
        {
            if (IsValid(toAddress))
            {
                MailMessage message = MakeMessage(toAddress);
                smtpClient.Send(message);
            }
        }

        public MailMessage MakeMessage(string toAddress)
        {
            MailMessage message = new MailMessage("orders@kelly.com", toAddress);
            message.IsBodyHtml = false;
            message.Subject = "Ship the order";
            message.Body = string.Format("Payment is processed for Order number ***. Please ship the order.");
            return message;
        }

        public bool IsValid(string emailAddress)
        {
            return Regex.IsMatch(emailAddress, @"^([0-9a-zA-Z]([-\.\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,9})$");
        }
    }
}