﻿using OrderingApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OrderingApp.Controllers
{
    public class OrdersController : Controller
    {
        public bool OrderProduct(string productId, int qty, string creditCardNumber, decimal amount)
        {
            var result = CheckInventory(productId, qty);
            var ccValidatedResult = false;
            if(result == true)
            {
                ccValidatedResult = ChargePayment(creditCardNumber, amount);
            }
            return ccValidatedResult;
        }

        private bool CheckInventory(string productId, int qty)
        {
            string existingProductId = "EarPhones";
            int existingQuantity = 100;
            bool result = false;

            if(productId.ToUpper() == existingProductId.ToUpper() && qty <= existingQuantity)
            {
                result = true;
            }
            return result;
        }

        private bool ChargePayment(string creditCardNumber, decimal amount)
        {
            string validCardNumber = "4147145678620965";
            bool ccValidationResult = false;

            if(creditCardNumber == validCardNumber)
            {
                FakeSmtpClient fakeClient = new FakeSmtpClient();
                EmailHelper helper = new EmailHelper(fakeClient);

                helper.SendOrderEmail("shippingDepartment@kelly.com");
                ccValidationResult = true;
            }
            return ccValidationResult;
        }

        
    }
}