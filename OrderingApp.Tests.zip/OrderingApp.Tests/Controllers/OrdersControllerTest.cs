﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OrderingApp;
using OrderingApp.Controllers;

namespace OrderingApp.Tests.Controllers
{
    [TestClass]
    public class OrdersControllerTest
    {  
        [TestMethod]
        public void Order_Product_Test()
        {
            // Arrange
            OrdersController controller = new OrdersController();

            // Act
            var result = controller.OrderProduct("earphones",100, "4147145678620965",49);

            // Assert
            Assert.IsTrue(result,"Requested product and quantity is ordered");
        }

        [TestMethod]
        public void Order_Product_InValidCCNumber_Test()
        {
            // Arrange
            OrdersController controller = new OrdersController();

            // Act
            var result = controller.OrderProduct("earphones", 100, "4147145678620885", 49);

            // Assert
            Assert.IsFalse(result, "Credit card number is not valid");
        }

        [TestMethod]
        public void Order_Product_ExcessQuantity_Test()
        {
            // Arrange
            OrdersController controller = new OrdersController();

            // Act
            var result = controller.OrderProduct("earphones", 200, "4147145678620965", 49);

            // Assert
            Assert.IsFalse(result, "Credit card number is not valid");
        }

        [TestMethod]
        public void Order_Product_InValidProduct_Test()
        {
            // Arrange
            OrdersController controller = new OrdersController();

            // Act
            var result = controller.OrderProduct("headphones", 100, "4147145678620965", 49);

            // Assert
            Assert.IsFalse(result, "ProductID is invalid");
        }
    }
}
